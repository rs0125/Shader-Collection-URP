﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum ScreenOffDelayTimeEnum
    {
        THREE,
        TEN ,
        THIRTY ,
        SIXTY,
        THREE_HUNDRED,
        SIX_HUNDRED ,
        NEVER 
    }
}
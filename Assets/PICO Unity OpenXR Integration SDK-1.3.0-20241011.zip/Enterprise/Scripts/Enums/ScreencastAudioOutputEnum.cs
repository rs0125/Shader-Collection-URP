﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum ScreencastAudioOutputEnum
    {
        AUDIO_ERROR=0,
        AUDIO_SINK = 1,
        AUDIO_TARGET = 2,
        AUDIO_SINK_TARGET = 3,
    }
}
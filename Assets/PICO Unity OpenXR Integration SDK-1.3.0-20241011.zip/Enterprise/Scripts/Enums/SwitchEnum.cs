﻿namespace Unity.XR.PICO.TOBSupport
{
    public enum SwitchEnum
    {
        S_ON=0,
        S_OFF=1
    }
}